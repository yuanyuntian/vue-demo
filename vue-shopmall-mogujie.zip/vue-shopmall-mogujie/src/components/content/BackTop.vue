<template>
    <div class="backtop">
        <img src="../../assets/img/common/top.png" alt="">
    </div>
</template>


<script>
export default {
}
</script>

<style scoped>
.backtop {
  position: fixed;
  right: 10px;
  bottom: 60px;
  z-index: 11;
}
.backtop img {
  width: 43px;
  height: 43px;
}
</style>