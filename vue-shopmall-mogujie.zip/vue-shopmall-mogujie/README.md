# vue_mall

## 手机端商城项目 技术栈Vue Vue router Vuex

## api接口开头：在src/network/request里面
